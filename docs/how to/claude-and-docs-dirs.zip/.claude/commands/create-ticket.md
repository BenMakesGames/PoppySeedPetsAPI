---
description: Create detailed implementation ticket(s) from a feature description
argument-hint: <feature description>
---

# Create Ticket: $ARGUMENTS

You are creating one or more implementation tickets based on the user's feature description. The goal is to produce tickets detailed enough that `/ticket` can implement them without ambiguity. Follow this structured workflow:

## Phase 1: Research

Thorough codebase research is critical — tickets that reference wrong patterns or miss existing infrastructure cause implementation friction.

1. Read recently completed tickets in `docs/tickets/complete/` to understand the ticket format, level of detail, and conventions (these are your format exemplars)
2. Read the relevant `docs/` reference files and `CLAUDE.md` files for the areas involved
3. Identify the existing codebase patterns most relevant to the feature. The user's description will often reference analogous systems (e.g., "like the Hattier"). Thoroughly read those analogous systems — entities, services, controllers, frontend components, enums, helpers — so you can mirror their patterns accurately in the ticket
4. Identify any entities, enums, services, or infrastructure that the new feature will need to touch or extend
5. Check for naming conventions, file organization patterns, and architectural constraints

## Phase 2: Scope

Determine how many tickets are needed. The user may describe one feature or several related features. Consider:

- **One ticket per deployable unit of work**: Each ticket should be implementable and testable on its own
- **Dependency ordering**: If ticket B depends on ticket A's artifacts, make that explicit in B's Prerequisites section
- **User guidance**: The user may suggest how to split the work — follow their lead

Present the proposed ticket split to the user and confirm before writing.

## Phase 3: Clarify

Ask the user about anything that would block writing a precise ticket:

- **Ambiguities**: Requirements that could be interpreted multiple ways
- **Design choices**: Decisions that affect the ticket structure (e.g., dialog vs. page, new entity vs. extending existing)
- **Scope boundaries**: What's in vs. out for each ticket
- **Data/content questions**: Specific values, names, or configurations needed

Keep questions focused and concrete. Don't ask about things you can reasonably infer from the codebase patterns you've already read.

## Phase 4: Write Tickets

Write each ticket to `docs/tickets/<ticket-name>.md` (no date prefix — dates are added when tickets are completed).

### Ticket Format

Follow this section structure:

```markdown
# Ticket Title

## Summary
1-2 sentences describing the change at a high level.

## Context
**Current behavior**: What exists today.
**New behavior**: What will exist after implementation.

## Prerequisites
- List any tickets, features, or artifacts that must exist before this ticket can be implemented
- Omit this section entirely if there are no prerequisites

## Backend
### 1. Step Title
Detailed implementation instructions referencing specific files, patterns, and conventions from the codebase. Include method signatures, field definitions, and endpoint paths.
### 2. Next Step Title
...

## Frontend
### 1. Step Title
...

## Files
### Create
- Full file paths for new files
### Modify
- Full file paths with brief description of what changes
### Delete
- Full file paths (if any)

## Test Plan
- [ ] Testable assertions as a checklist
```

### Writing Guidelines

- **Be specific**: Reference exact file paths, entity field types, method signatures, endpoint URLs, and enum values. The implementer should not need to guess.
- **Mirror existing patterns**: When the ticket calls for something analogous to existing code (e.g., "like UserUnlockedAura"), spell out the parallel structure explicitly rather than just saying "follow the pattern."
- **Include both backend and frontend sections** when the feature spans both. Omit a section (with a note like "No backend changes required") if it doesn't apply.
- **Data migrations**: If new entities or enum values require database seeding or backfilling, describe the migration in the Backend section.
- **Keep scope tight**: Each ticket should be one coherent unit of work. If you find yourself writing a ticket that feels too large, consider splitting it.
- **Don't over-specify UI**: Give enough structure (component names, template sketches, behavioral descriptions) for the implementer to build it, but don't dictate every CSS class or pixel.

## Phase 5: Review

After writing, do a quick self-check:

- Does each ticket's Prerequisites section accurately list what must exist first?
- Are file paths consistent between the Backend/Frontend sections and the Files section?
- Would an implementer using `/ticket` have enough detail to build this without re-reading the analogous systems?
- Are the tickets ordered so that dependencies flow forward (no circular prerequisites)?

Present the completed tickets to the user with a brief summary of each.
