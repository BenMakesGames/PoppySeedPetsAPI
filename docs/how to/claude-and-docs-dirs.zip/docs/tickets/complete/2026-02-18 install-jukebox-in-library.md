# Install Jukebox in Library

## Summary

Replace the Jukebox item's daily "Listen" use action with an "Install in Library" action. When used, the Jukebox is consumed from inventory and permanently installed in the user's Library. The installed Jukebox appears in the Library's add-ons section (alongside Star Kindred and Secret Passage). For this ticket, the installed Jukebox is display-only with no interactive action.

## Context

**Current behavior**: The Jukebox (item ID 273, obtained from Box Box) has a "Listen" action (`POST /item/box/jukebox/{inventory}/listen`) that can be used once per day when the Jukebox is in the player's Home or Mantle. It gives all home pets +2 safety and +1 Music XP. This is tracked via a "Listened to Jukebox" UserQuest record.

**New behavior**: The Jukebox becomes an installable item for the Library, following the pattern used by Greenhouse add-ons (Bird Bath, Composter, Fish Statue, Moondial). The old listen/play functionality is removed entirely.

## Prerequisites

- User must have the Library feature unlocked
- Library must not already have a Jukebox installed

## Backend

### 1. Create Library Entity

Create `PoppySeedPetsAPI/src/Entity/Library.php` following the Greenhouse entity pattern:

- `id: int` (auto-generated)
- `owner: User` (OneToOne, inversedBy `library` on User, not nullable)
- `hasJukebox: bool` (default `false`, serialization group `"myLibrary"`)

Add the inverse side on `User.php`:

- `library: ?Library` (OneToOne, mappedBy `owner`, cascade persist/remove)
- `getLibrary(): ?Library` and `setLibrary(Library): self`

### 2. Create GetLibraryController

`GET /library` in `PoppySeedPetsAPI/src/Controller/Library/GetLibraryController.php`:

- Requires authentication
- Validates user has Library feature unlocked
- Returns the user's Library entity serialized with group `"myLibrary"`
- If no Library entity exists yet, create one (lazy initialization, same as how Greenhouse works)

### 3. Create InstallJukeboxController

`POST /item/jukebox/{inventory}/install` in `PoppySeedPetsAPI/src/Controller/Item/InstallJukeboxController.php`:

- Requires authentication
- `ItemControllerHelpers::validateInventory($user, $inventory, 'jukebox/#/install')`
- Check `$user->hasUnlockedFeature(UnlockableFeatureEnum::Library)` — error if not
- Get or create the Library entity (lazy init)
- Check `!$library->getHasJukebox()` — error if already installed (friendly message like "Your Library already has a Jukebox!")
- `$em->remove($inventory)` (consumes the item)
- `$library->setHasJukebox(true)`
- `$em->flush()`
- Return `$responseService->itemActionSuccess('You install the Jukebox in your Library!', ['itemDeleted' => true])`

No pet selection or pet reward — this is a simple direct install (uses the `item` link type, not the `page`/choosePet flow).

### 4. Delete ListenToJukeboxController

Remove `PoppySeedPetsAPI/src/Controller/Item/Pinata/Box/ListenToJukeboxController.php` entirely.

### 5. Database Migrations

**Schema migration** (auto-generated): After creating the Library entity and updating User, run `make:migration` to generate the schema migration for the new `library` table and its foreign key.

**Data migration** (hand-written, runs after schema migration):

1. Backfills: creates a Library row for every user that has the Library feature unlocked (query `user_unlocked_feature` where `feature = 'Library'`)
2. Updates the Jukebox item's `useActions` column — change from the listen action to: `[["Install in Library", "jukebox/#/install"]]`
3. Deletes "Listened to Jukebox" records from the `user_quest` table (cleanup)

## Frontend

### 1. Create Library Model

Create `PoppySeedPetsApp/src/app/model/library/my-library.serialization-group.ts`:

```typescript
export interface MyLibrarySerializationGroup {
  hasJukebox: boolean;
}
```

### 2. Update Library Component

In `PoppySeedPetsApp/src/app/module/library/page/library/library.component.ts`:

- Add a `library: MyLibrarySerializationGroup` property
- On init, fetch `GET /library` and store the result
- After a successful Jukebox install (detected via `userInventoryChanged` or a reload), re-fetch library data

### 3. Update Library Template

In `PoppySeedPetsApp/src/app/module/library/page/library/library.component.html`, add a Jukebox block inside the existing `div.add-ons` section (after the Star Kindred block, before the Hollow Earth / Hidden Lever block):

```html
@if(library?.hasJukebox)
{
  <div>
    <h4>Jukebox</h4>
    <img src="/assets/images/items/box/jukebox.svg" alt="" aria-hidden="true" />
  </div>
}
```

No action button — the Jukebox is display-only for this ticket.

## Files

### Create
- `PoppySeedPetsAPI/src/Entity/Library.php`
- `PoppySeedPetsAPI/src/Controller/Library/GetLibraryController.php`
- `PoppySeedPetsAPI/src/Controller/Item/InstallJukeboxController.php`
- `PoppySeedPetsAPI/migrations/` (auto-generated schema migration via `make:migration` + hand-written data migration)
- `PoppySeedPetsApp/src/app/model/library/my-library.serialization-group.ts`

### Modify
- `PoppySeedPetsAPI/src/Entity/User.php` — add `library` OneToOne relationship
- `PoppySeedPetsApp/src/app/module/library/page/library/library.component.ts` — fetch library data
- `PoppySeedPetsApp/src/app/module/library/page/library/library.component.html` — add Jukebox to add-ons

### Delete
- `PoppySeedPetsAPI/src/Controller/Item/Pinata/Box/ListenToJukeboxController.php`

## Test Plan

- [ ] Install Jukebox from Home inventory — should succeed, item consumed, Jukebox appears in Library
- [ ] Install Jukebox from Basement inventory — should succeed
- [ ] Try to install when Library is not unlocked — should show error
- [ ] Try to install when Library already has a Jukebox — should show friendly error
- [ ] Visit Library after install — Jukebox image visible in add-ons section
- [ ] Jukebox has no clickable action in Library (display-only)
- [ ] Old "Listen" action no longer appears on Jukebox items
- [ ] Melting recipe for Jukebox still works (unchanged)

## Learnings

### Architectural decisions
- **Used explicit response DTOs instead of serialization groups** for the new `GET /library` endpoint. The ticket originally specified serialization groups (`#[Groups(["myLibrary"])]`), but the project is actively migrating away from them. The controller returns a hand-built array `['hasJukebox' => $library->getHasJukebox()]` directly to `$responseService->success()`. This is the preferred pattern going forward.
- **Lazy initialization pattern** for the Library entity: both `GetLibraryController` and `InstallJukeboxController` create the Library entity if it doesn't exist yet. The data migration also backfills for existing users, so lazy init only applies to edge cases.

### Interesting tidbits
- **Item action "failures" should use `itemActionSuccess`**, not exceptions. The frontend expects all item action responses in the `itemActionSuccess` format. Throwing `PSPInvalidOperationException` would break the item dialog flow. The "already installed" case returns `itemActionSuccess('Your Library already has a Jukebox!')` with no `itemDeleted` flag — the item stays, the user just sees the message.

### Problems encountered
- **Doctrine `make:migration` generates massive phantom diffs** due to DBAL 3.x → 4.x upgrade. The database still has `COMMENT '(DC2Type:datetime_immutable)'` on datetime columns from the old DBAL version. DBAL 4.x no longer uses these comments, so the schema comparator sees every datetime column as "changed" and generates ALTERs to strip the comments. The workaround is to manually trim auto-generated migrations to only the intended changes. A one-time cleanup migration to strip all `DC2Type` comments would fix this permanently.

### Rejected alternatives
- **Serialization groups on the Library entity** — rejected because the project is moving away from `#[Groups]` annotations. Using explicit DTO mapping keeps the response shape visible in the controller rather than scattered across entity files.
