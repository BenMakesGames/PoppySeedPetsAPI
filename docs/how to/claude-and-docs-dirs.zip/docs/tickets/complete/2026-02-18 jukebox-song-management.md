# Jukebox Song Management

## Summary

Add a Song entity and UserUnlockedSong junction table to track which songs each player has unlocked. Create an endpoint to return the player's song library with unlock status. Add a jukebox management dialog in the Library where players can toggle unlocked songs on and off — the active playlist is stored in local storage (not the backend). Actual audio playback is handled by a separate ticket.

## Context

**Current behavior**: The Jukebox is installed in the Library as a display-only add-on (from the "Install Jukebox in Library" ticket). Players can see it but cannot interact with it.

**New behavior**: The Jukebox add-on block gains a "Manage" button. Clicking it opens a dialog showing the player's song library — unlocked songs have toggle switches, locked songs appear as mystery entries. Toggling a song adds or removes it from a local storage playlist. The audio files live in the S3 assets bucket (mirrored to `src/assets/` in development). If a player edits their local storage directly, that's fine — we are not enforcing DRM.

## Prerequisites

- Jukebox installed in Library (completed in "Install Jukebox in Library" ticket)

## Backend

### 1. Create Song Entity

Create `PoppySeedPetsAPI/src/Entity/Song.php`:

- `id: int` (auto-generated)
- `name: string` (display name, e.g. "Poppy's Theme", max 100)
- `filename: string` (path relative to assets root, e.g. `music/poppys-theme.mp3`, max 200)

### 2. Create UserUnlockedSong Entity

Create `PoppySeedPetsAPI/src/Entity/UserUnlockedSong.php`, following the `UserUnlockedAura` pattern:

- `id: int` (auto-generated)
- `user: User` (ManyToOne, inversedBy `unlockedSongs` on User, not nullable)
- `song: Song` (ManyToOne, not nullable)
- `unlockedOn: DateTimeImmutable` (set in constructor to `new \DateTimeImmutable()`)
- `comment: string` (max 255, describes how the song was unlocked)
- Unique constraint on `(user_id, song_id)`

Add the inverse side on `User.php`:

- `unlockedSongs: Collection<UserUnlockedSong>` (OneToMany, mappedBy `user`)
- `getUnlockedSongs(): Collection`

### 3. Create JukeboxService

Create `PoppySeedPetsAPI/src/Service/JukeboxService.php`, following the `HattierService` pattern:

**Dependencies**: `EntityManagerInterface`

**Methods**:

- `getSongsAvailable(User $user): array` — Returns all songs with unlock status. For each Song, returns `['name' => ..., 'filename' => ..., 'unlocked' => bool, 'unlockedOn' => ?DateTimeImmutable, 'comment' => ?string]`. Follows the `HattierService::getAurasAvailable` pattern.

- `userHasUnlockedSong(User $user, Song $song): bool` — Checks if user has unlocked a specific song. Uses a per-request cache (`$userSongsPerRequestCache`) keyed by `userId-songId`, same pattern as `HattierService::userHasUnlocked`.

- `playerUnlockSong(User $user, Song $song, string $comment): UserUnlockedSong` — Idempotent: if already unlocked, returns existing record. Otherwise creates and persists a new `UserUnlockedSong`. Creates a player activity log: `'You unlocked the song "X"!'` tagged with `PlayerActivityLogTagEnum::Music`. Follows the `HattierService::playerUnlockAura` pattern.

- `unlockStartingSongs(User $user): void` — Grants a set of starter songs (looked up by name). Follows `HattierService::unlockStartingAuras`. The starter song list is hardcoded in this method (analogous to the hardcoded starter aura names). The comment should be something like `'This song came with your Jukebox.'`

### 4. Create GetJukeboxSongsController

`GET /library/jukebox/songs` in `PoppySeedPetsAPI/src/Controller/Library/GetJukeboxSongsController.php`:

- Requires authentication
- Validates user has Library feature unlocked
- Validates user's Library has a Jukebox installed (`$library->getHasJukebox()`)
- Lazy-initializes starter songs: if user has zero `UserUnlockedSong` records, calls `$jukeboxService->unlockStartingSongs($user)` then flushes
- Returns `$responseService->success($jukeboxService->getSongsAvailable($user))`

### 5. Add PlayerActivityLogTagEnum::Music

Add `public const string Music = 'Music';` to `PoppySeedPetsAPI/src/Enum/PlayerActivityLogTagEnum.php`.

### 6. Database Migrations

**Schema migration** (auto-generated): After creating the Song and UserUnlockedSong entities and updating User, run `make:migration` to generate the schema migration for the new tables, foreign keys, and unique constraint.

**Data migration** (hand-written, runs after schema migration):

1. Seeds the `song` table with the initial set of available songs (name + filename pairs)
2. For every user who already has a Jukebox installed (query: users whose Library row has `has_jukebox = 1`), inserts `UserUnlockedSong` rows for the starter songs with comment `'This song came with your Jukebox.'`

## Frontend

### 1. Create JukeboxSong Model

Create `PoppySeedPetsApp/src/app/model/library/jukebox-song.model.ts`:

```typescript
export interface JukeboxSong {
  name: string;
  filename: string;
  unlocked: boolean;
  unlockedOn: string | null;
  comment: string | null;
}
```

### 2. Create JukeboxSongsDialog

Create `PoppySeedPetsApp/src/app/module/library/dialog/jukebox-songs/jukebox-songs.dialog.ts` (and `.html`, `.scss`):

**Behavior**:
- On open, fetches `GET /library/jukebox/songs` and stores the response
- Displays unlocked songs with toggle checkboxes
- Displays locked songs as mystery entries (e.g. "???") with no toggle
- Reading/writing the active playlist from/to `localStorage` key `jukebox-playlist` (JSON array of filenames)
- Toggling a song adds or removes its `filename` from the localStorage array
- Static `open(matDialog: MatDialog)` method following existing dialog patterns

### 3. Update Library Template

In `library.component.html`, add a "Manage" button to the Jukebox add-on block.

### 4. Update Library Component

In `library.component.ts`, add the `openJukebox()` method that opens the `JukeboxSongsDialog`.

### 5. Register Dialog in Library Module

Not needed — `JukeboxSongsDialog` is a standalone component opened dynamically via `MatDialog.open()`.

## Files

### Create
- `PoppySeedPetsAPI/src/Entity/Song.php`
- `PoppySeedPetsAPI/src/Entity/UserUnlockedSong.php`
- `PoppySeedPetsAPI/src/Service/JukeboxService.php`
- `PoppySeedPetsAPI/src/Controller/Library/GetJukeboxSongsController.php`
- `PoppySeedPetsAPI/migrations/2026/02/Version20260218250000.php` (schema migration)
- `PoppySeedPetsAPI/migrations/2026/02/Version20260218250001.php` (data migration)
- `PoppySeedPetsApp/src/app/model/library/jukebox-song.model.ts`
- `PoppySeedPetsApp/src/app/module/library/dialog/jukebox-songs/jukebox-songs.dialog.ts`
- `PoppySeedPetsApp/src/app/module/library/dialog/jukebox-songs/jukebox-songs.dialog.html`
- `PoppySeedPetsApp/src/app/module/library/dialog/jukebox-songs/jukebox-songs.dialog.scss`

### Modify
- `PoppySeedPetsAPI/src/Entity/User.php` — add `unlockedSongs` OneToMany relationship
- `PoppySeedPetsAPI/src/Enum/PlayerActivityLogTagEnum.php` — add `Music` constant
- `PoppySeedPetsApp/src/app/module/library/page/library/library.component.html` — add "Manage" button to Jukebox block
- `PoppySeedPetsApp/src/app/module/library/page/library/library.component.ts` — add `openJukebox()` method
- `CLAUDE.md` — add dialog pattern documentation (no mat-dialog-* components)

### Delete
- None

## Test Plan

- [ ] `GET /library/jukebox/songs` returns all songs with unlock status
- [ ] First call to the endpoint for a new jukebox owner grants starter songs (lazy init)
- [ ] Starter songs appear with `unlocked: true`; other songs appear with `unlocked: false`
- [ ] Songs endpoint requires authentication
- [ ] Songs endpoint rejects users without Library feature unlocked
- [ ] Songs endpoint rejects users whose Library has no Jukebox
- [ ] Clicking "Manage" on Jukebox add-on opens the songs dialog
- [ ] Unlocked songs show toggle checkboxes; locked songs show as "???"
- [ ] Toggling a song on adds its filename to `localStorage['jukebox-playlist']`
- [ ] Toggling a song off removes its filename from the localStorage playlist
- [ ] Closing and reopening the dialog preserves toggle state (reads from localStorage)
- [ ] Data migration seeds Song table and backfills starter songs for existing jukebox owners

## Learnings

### Architectural decisions
- **JukeboxService does not depend on CommentFormatter** unlike HattierService. The `getSongsAvailable` method returns raw comments rather than formatted ones, since song unlock comments are simple plain-text strings (e.g. "This song came with your Jukebox.") that don't need formatting. This keeps the service simpler.
- **Standalone dialog, not module-declared** — `JukeboxSongsDialog` is a standalone component (uses `imports` in `@Component`), so it does not need to be added to `LibraryModule`'s declarations. Angular's `MatDialog.open()` handles standalone components natively.

### Interesting tidbits
- **This project does not use mat-dialog-* components** (`mat-dialog-title`, `mat-dialog-content`, `mat-dialog-actions`). All dialogs use the custom `<div class="dialog"><h4>Title</h4><div class="dialog-body">...</div></div>` pattern. This has been documented in the root `CLAUDE.md` for future reference.
- **Song names use literal filenames** (e.g. `frogs_life`) rather than human-readable display names. This was a deliberate user choice for the initial song set.

### Related areas affected
- The `PlayerActivityLogTagEnum::Music` constant and `UserActivityLogTag` row (created by migration/manual insert) will be needed by the "Unlock Songs via Pet Activities" ticket.
- The `jukebox-playlist` localStorage key will be consumed by the "Play Jukebox Songs" ticket for audio playback.

### Rejected alternatives
- **mat-dialog-* template components** — explicitly rejected; the project has its own dialog markup pattern and should never use Angular Material's dialog content directives.
