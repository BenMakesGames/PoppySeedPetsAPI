# Play Jukebox Songs

## Summary

Add an audio playback system that plays songs from the player's local storage playlist. The player controls (play/pause, skip, volume) persist across page navigation. Songs are loaded from the S3 assets bucket (mirrored to `src/assets/` in development).

## Context

**Current behavior**: Players can toggle songs on and off in the Jukebox management dialog (from the "Jukebox Song Management" ticket), but nothing actually plays. The `jukebox-playlist` localStorage key contains an array of filenames, but no code reads it.

**New behavior**: A persistent audio player reads the `jukebox-playlist` from localStorage and plays songs from the list. The player is a small, unobtrusive UI element (e.g. a floating mini-player or a bar at the bottom of the screen) that persists across Angular route changes. Players can play/pause, skip to the next track, and adjust volume. Volume preference is saved to localStorage. Playback is shuffle-based (random order from the playlist). The player only appears when the playlist is non-empty and the user has started playback.

## Prerequisites

- "Jukebox Song Management" ticket completed (localStorage playlist populated via toggle UI)

## Backend

No backend changes required. All audio files are served as static assets from S3/assets.

## Frontend

### 1. Create JukeboxPlayerService

Create a service in the shared module (or library module) that manages audio playback:

- Reads `jukebox-playlist` from localStorage to get the list of active song filenames
- Uses the HTML5 `Audio` API for playback
- Shuffles the playlist and plays songs in sequence
- Handles track advancement (when a song ends, play the next)
- Exposes observable state: `isPlaying`, `currentTrack`, `volume`
- Saves volume to localStorage key `jukebox-volume`
- The service should be a singleton (provided in root or shared module) so playback survives route changes

### 2. Create JukeboxPlayerComponent

A small persistent UI element, placed in the app shell (e.g. `app.component.html`) so it's always visible:

- Shows current song name (derived from filename or fetched from the songs API)
- Play/pause button
- Skip/next button
- Volume slider
- Only visible when the playlist has songs and the user has interacted with play
- Respects browser autoplay policies (require user interaction to start)

### 3. Asset Path Resolution

Song filenames in localStorage are relative paths like `music/poppys-theme.mp3`. The component/service constructs the full URL using the environment's asset base URL:

- Development: `/assets/{filename}`
- Production: `{S3 bucket URL}/{filename}` (or served via the same domain if CloudFront is configured)

Use the existing environment configuration pattern for this.

## Files

### Create
- `PoppySeedPetsApp/src/app/service/jukebox-player.service.ts` (or in shared module)
- `PoppySeedPetsApp/src/app/component/jukebox-player/jukebox-player.component.ts`
- `PoppySeedPetsApp/src/app/component/jukebox-player/jukebox-player.component.html`
- `PoppySeedPetsApp/src/app/component/jukebox-player/jukebox-player.component.scss`

### Modify
- `PoppySeedPetsApp/src/app/app.component.html` — include `<app-jukebox-player />` in the app shell
- App module or shared module — register the new component and service

### Delete
- None

## Test Plan

- [ ] Audio plays when the user clicks play and the playlist is non-empty
- [ ] Playback continues across route changes (navigating between pages)
- [ ] Skip button advances to the next song in the shuffled playlist
- [ ] Play/pause toggles playback correctly
- [ ] Volume slider adjusts audio volume
- [ ] Volume preference persists across page reloads (saved to localStorage)
- [ ] Player is hidden when the playlist is empty
- [ ] Playback respects browser autoplay policies (no audio until user interaction)
- [ ] When the playlist changes (songs toggled in the Manage dialog), the player picks up the changes
- [ ] Songs loop — after playing all songs in the playlist, it reshuffles and starts again

## Learnings

### Architectural decisions
- **Jukebox replaces page music entirely** — Per user decision, the old page-specific music system (`pageMeta.song` + `SoundsService.playSong/stopSong` in `doRouterActivate`) was removed. The jukebox is now the sole music system. Pages that previously played `the-ocean` (portal, register, reset-passphrase, park) no longer trigger any background music.
- **Player placed in nav menu, not app shell** — Instead of a floating bottom bar or fixed-position element, the jukebox player was placed inside the menu component (`menu.component.html`) below the weather report. This keeps it unobtrusive and avoids z-index conflicts with the messages component.
- **Reuses existing musicVolume** — Rather than creating a separate `jukebox-volume` localStorage key, the jukebox subscribes to `ThemeService.musicVolume`, which is already managed in the Settings page. No new volume slider was needed in the player itself.
- **Component is standalone: false** — Since it's used inside `MenuComponent` (which is declared in `AppModule`), the jukebox player follows the same pattern: `standalone: false` and added to `AppModule` declarations.
- **Service is providedIn: root** — The `JukeboxPlayerService` is a root singleton so audio playback state survives route changes and the nav menu opening/closing.

### Interesting tidbits
- **SoundsService methods left intact** — `playSong()` and `stopSong()` remain on `SoundsService` as dead code. They're no longer called from anywhere, but weren't removed since they don't hurt and could theoretically be useful for other features.
- **Track display name derived from filename** — Since the localStorage playlist stores filenames like `music/frogs_life.mp3`, the display name is derived by stripping the directory prefix and file extension. No API call is needed to get song names for the player UI.

### Related areas affected
- `PreservePreviousSong` symbol was removed from `app.component.ts` — any code importing it will break (only `stats.component.ts` was importing it, and that import was removed).
- The `SoundsService` is no longer injected into `AppComponent` — if future features need page-specific music, a new mechanism would need to be built.

### Rejected alternatives
- **Floating bottom bar** — Rejected because it would conflict with the existing messages component which already uses fixed positioning at the bottom of the screen.
- **Separate jukebox-volume localStorage key** — Rejected in favor of reusing the existing `ThemeService.musicVolume`, which keeps volume management centralized in Settings.
