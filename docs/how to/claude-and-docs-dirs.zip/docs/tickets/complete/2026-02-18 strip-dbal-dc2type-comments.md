# Strip DBAL DC2Type Column Comments

## Summary

Create a one-time cleanup migration that strips all `(DC2Type:...)` comments from datetime columns in the database. This eliminates the phantom diffs that `make:migration` generates after the DBAL 3.x to 4.x upgrade, so that future migrations only contain intentional schema changes.

## Context

**Current behavior**: DBAL 3.x stored type hints like `COMMENT '(DC2Type:datetime_immutable)'` on datetime columns. After upgrading to DBAL 4.x, these comments are no longer used. The schema comparator sees every datetime column with a `DC2Type` comment as "changed" and generates `ALTER TABLE` statements to strip them. This means every `make:migration` produces dozens of spurious ALTERs that must be manually trimmed — a tedious and error-prone process.

**New behavior**: After running the cleanup migration, `make:migration` produces clean diffs containing only actual schema changes. No more manual trimming required.

**References**: This issue is documented in `PoppySeedPetsAPI/docs/Architecture Decisions.md` (section "Doctrine `make:migration` generates phantom diffs (DBAL 4.x)") and was also encountered during the Jukebox ticket.

## Prerequisites

- None — this is a standalone infrastructure cleanup

## Backend

### 1. Identify All Affected Columns

Run `make:migration` to generate a migration containing all the phantom diffs. This reveals every column that still has a `DC2Type` comment. Do **not** keep this generated migration — it's only used for reference.

Alternatively, query the database directly:

```sql
SELECT TABLE_NAME, COLUMN_NAME, COLUMN_COMMENT
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = DATABASE()
  AND COLUMN_COMMENT LIKE '%(DC2Type:%'
ORDER BY TABLE_NAME, COLUMN_NAME;
```

### 2. Create a Hand-Written Cleanup Migration

Create a new migration in `PoppySeedPetsAPI/migrations/` that strips the `DC2Type` comments from all affected columns. Rather than writing individual `ALTER TABLE` statements for each column, use a dynamic approach:

```php
public function up(Schema $schema): void
{
    $rows = $this->connection->fetchAllAssociative(<<<'SQL'
        SELECT TABLE_NAME, COLUMN_NAME, COLUMN_TYPE, IS_NULLABLE, COLUMN_DEFAULT, EXTRA
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND COLUMN_COMMENT LIKE '%(DC2Type:%'
        ORDER BY TABLE_NAME, COLUMN_NAME
    SQL);

    foreach ($rows as $row) {
        $table  = $row['TABLE_NAME'];
        $column = $row['COLUMN_NAME'];
        $type   = $row['COLUMN_TYPE'];

        $nullable = $row['IS_NULLABLE'] === 'YES' ? 'NULL' : 'NOT NULL';
        $default  = $row['COLUMN_DEFAULT'] !== null
            ? sprintf("DEFAULT '%s'", $row['COLUMN_DEFAULT'])
            : ($row['IS_NULLABLE'] === 'YES' ? 'DEFAULT NULL' : '');

        $this->addSql(
            "ALTER TABLE `$table` MODIFY `$column` $type $nullable $default COMMENT ''"
        );
    }
}
```

The `down()` method can be left empty or throw an exception — re-adding `DC2Type` comments is not desirable.

### 3. Verify Clean Diff

After running the migration, run `make:migration` again. It should report "No database changes were detected" (or produce only a trivially empty migration class). If any phantom diffs remain, the cleanup missed some columns — investigate and fix.

### 4. Update Architecture Decisions

In `PoppySeedPetsAPI/docs/Architecture Decisions.md`, update or remove the "Doctrine `make:migration` generates phantom diffs (DBAL 4.x)" section to note that the issue has been resolved. Optionally keep a brief note for historical context.

## Frontend

No frontend changes required.

## Files

### Create
- `PoppySeedPetsAPI/migrations/VersionXXXX.php` (hand-written cleanup migration)

### Modify
- `PoppySeedPetsAPI/docs/Architecture Decisions.md` — update/remove the phantom diffs section

### Delete
- None

## Test Plan

- [ ] Run `make:migration` before the cleanup — confirm it generates phantom datetime ALTERs
- [ ] Run the cleanup migration (`doctrine:migrations:migrate`)
- [ ] Run `make:migration` after the cleanup — confirm it reports no changes detected
- [ ] Verify the application works normally (run `vendor/bin/phpunit`)
- [ ] Spot-check a few datetime columns in the database — confirm `DC2Type` comments are gone
- [ ] Create a test entity change (e.g., add a nullable column to any entity), run `make:migration`, and confirm the generated migration contains only that one change

## Learnings

### Architectural decisions
- Used a dynamic `INFORMATION_SCHEMA` query rather than hardcoding column names. This makes the migration self-describing — it finds and fixes whatever DC2Type comments exist at runtime, regardless of schema changes between writing and running.

### Problems encountered
- The `EXTRA` column from `INFORMATION_SCHEMA.COLUMNS` can contain values like `on update CURRENT_TIMESTAMP` or `DEFAULT_GENERATED`. The `DEFAULT_GENERATED` value is an internal MySQL marker and should be excluded from the `MODIFY` statement (MySQL adds it implicitly), while `on update CURRENT_TIMESTAMP` must be preserved to avoid silently changing column behavior.

### Interesting tidbits
- DBAL 3.x used column comments as a metadata sideband to store PHP type information (`DC2Type:datetime_immutable`). DBAL 4.x dropped this mechanism entirely, but the comments lingered in existing databases. The schema comparator in DBAL 4.x sees these leftover comments as diffs because it no longer expects them.
- `ALTER TABLE ... MODIFY` in MySQL requires re-specifying the full column definition (type, nullability, default, extra) — you can't just change the comment in isolation.

### Workarounds / limitations
- Setting `COMMENT ''` (empty string) rather than removing the comment entirely. MySQL treats `COMMENT ''` the same as no comment for most purposes, and it's the simplest way to clear the value in a `MODIFY` statement.

### Rejected alternatives
- **Hardcoded ALTER statements**: Would have been fragile and required updating if new datetime columns were added between writing and running the migration.
- **Using `make:migration` output directly**: The auto-generated migration would have included the correct ALTERs, but it generates them in Doctrine's SQL format which may differ from the `MODIFY` approach and wouldn't be self-healing if run against a slightly different schema.
