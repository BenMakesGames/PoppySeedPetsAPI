# Museum: Prefer Self-Made Donations and Allow Upgrades

## Summary

When donating items to the Museum, prefer inventory copies made by the current player. If the player already donated an item that was NOT made by them, and they now own a self-made copy, allow them to re-donate ("upgrade") that museum entry to the self-made version. Show the item's maker below the item name on the donate page.

## Context

**Current behavior**: `GetDonatableItemsController` excludes all items the player has already donated to the Museum. There is no distinction between self-made and non-self-made copies. The donate page does not display who made each item, even though `createdBy` data is already included in the API response (via the `myInventory` serialization group on `Inventory.createdBy`).

**New behavior**: The donatable items list includes items that are already in the Museum IF the museum copy was not made by the player AND the player owns a self-made copy. The donate page shows "Made by [PlayerName]" below each item's name. `DonateController` handles the upgrade case by updating the existing `MuseumItem` instead of creating a new one, awarding no additional Favor for upgrades.

## Backend

### 1. Update GetDonatableItemsController query

In `PoppySeedPetsAPI/src/Controller/Museum/GetDonatableItemsController.php`, replace the current `NOT IN` subquery approach with a LEFT JOIN to `MuseumItem` so we can inspect the museum entry's `createdBy`:

**Remove** (line 52):
```php
->andWhere('item.id NOT IN (SELECT miitem.id FROM App\\Entity\\MuseumItem mi LEFT JOIN mi.item miitem WHERE mi.user=:user)')
```

**Replace with**:
```php
->leftJoin('App\\Entity\\MuseumItem', 'mi', 'WITH', 'mi.item = item AND mi.user = :user')
->andWhere('(mi.id IS NULL) OR ((mi.createdBy IS NULL OR mi.createdBy != :user) AND i.createdBy = :user)')
```

This WHERE clause allows two cases:
- `mi.id IS NULL` — item is not yet in the museum (standard donatable)
- The OR branch — item IS in the museum, but the museum copy's `createdBy` is not the current user, AND this inventory copy's `createdBy` IS the current user (upgrade-eligible)

The existing `GROUP BY item.id, enchData.enchantment` and `ORDER BY` remain unchanged. For the upgrade case, the WHERE clause already filters to only user-made copies, so the GROUP BY will always select a self-made copy for upgrade-eligible items.

### 2. Update DonateController to handle upgrades

In `PoppySeedPetsAPI/src/Controller/Museum/DonateController.php`:

**2a. Validation loop (lines 66–84)**: Change the existing museum-item check to allow upgrades instead of unconditionally skipping. Add an `$existingMuseumItems` array to cache results for the processing loop:

Before the validation loop, declare:
```php
$existingMuseumItems = [];
```

Replace the existing museum-item check block (lines 74–83):
```php
$existingItem = $em->getRepository(MuseumItem::class)->findOneBy([
    'user' => $user,
    'item' => $inventory[$i]->getItem()
]);

if($existingItem)
{
    unset($inventory[$i]);
    continue;
}
```

With:
```php
$existingItem = $em->getRepository(MuseumItem::class)->findOneBy([
    'user' => $user,
    'item' => $inventory[$i]->getItem()
]);

if($existingItem)
{
    $isUpgrade = $inventory[$i]->getCreatedBy()?->getId() === $user->getId()
        && $existingItem->getCreatedBy()?->getId() !== $user->getId();

    if(!$isUpgrade)
    {
        unset($inventory[$i]);
        continue;
    }

    $existingMuseumItems[$inventory[$i]->getId()] = $existingItem;
}
```

**2b. Processing loop (lines 92–104)**: Split into upgrade vs new-donation paths. Only new donations earn Favor and increment the stat.

Replace the processing loop and the code after it (lines 89–112) with:

```php
$totalMuseumPoints = 0;
$donatedItemNames = [];
$newDonationCount = 0;

foreach($inventory as $i)
{
    if(isset($existingMuseumItems[$i->getId()]))
    {
        // Upgrade existing museum entry
        $existingMuseumItems[$i->getId()]
            ->setCreatedBy($i->getCreatedBy())
            ->setComments($i->getComments());
    }
    else
    {
        // New donation
        $museumItem = (new MuseumItem(user: $user, item: $i->getItem()))
            ->setCreatedBy($i->getCreatedBy())
            ->setComments($i->getComments())
        ;

        $totalMuseumPoints += $i->getItem()->getMuseumPoints();
        $newDonationCount++;

        $em->persist($museumItem);
    }

    $donatedItemNames[] = $i->getItem()->getNameWithArticle();
    $em->remove($i);
}

$donationSummary = count($inventory) > 5 ? (count($inventory) . ' items') : ArrayFunctions::list_nice($donatedItemNames);

if($totalMuseumPoints > 0)
    $transactionService->getMuseumFavor($user, $totalMuseumPoints, 'You donated ' . $donationSummary . ' to the Museum.');

if($newDonationCount > 0)
    $userStatsRepository->incrementStat($user, UserStat::ItemsDonatedToMuseum, $newDonationCount);
```

Key differences from the current code:
- Upgrades update the existing `MuseumItem`'s `createdBy` and `comments` instead of creating a new one
- `totalMuseumPoints` and stat increment only count new donations, not upgrades
- The Favor transaction is skipped entirely if there are no new donations (only upgrades)

## Frontend

### 1. Add `isUpgrade` flag and "Replaces donated copy" subtitle

Rather than showing "Made by X" on all items, a backend `isUpgrade` flag distinguishes upgrade-eligible items from new donations. The donate page shows "Replaces donated copy" only on upgrade items, displayed inside the `<app-inventory-item>` component (so clicking the label selects the item).

**Backend (`Inventory.php`)**: Added a non-persisted `public bool $isUpgrade = false` property with the `myDonatableInventory` serialization group. Only serialized in the `GetDonatableItemsController` response.

**Backend (`GetDonatableItemsController.php`)**: After fetching paginated results, queries `MuseumItem` to find which result items already have museum entries for this user, then sets `$inv->isUpgrade = true` on matches.

**Frontend type (`my-inventory.serialization-group.ts`)**: Added `isUpgrade?: boolean`.

**`InventoryItemComponent`**: Renamed the `makerName` input to `subtitle` (a more generic name). The template displays the subtitle text directly (no "Made by" prefix). Renamed `.maker` CSS class to `.subtitle`.

**Donate page template**: Passes `[subtitle]="i.isUpgrade ? 'Replaces donated copy' : null"` to `<app-inventory-item>`.

### 2. Explanatory note for upgrade items

Added a `hasUpgradeItems` boolean to `MuseumDonateComponent`, computed from `results.results.some(r => r.isUpgrade)`. When true, a `<label>` note appears at the bottom of the page (alongside the existing item-bonuses note) explaining that "Replaces donated copy" items are ones already donated by someone else, and re-donating will replace the Museum entry to show the player's name as maker.

## Files

### Modify
- `PoppySeedPetsAPI/src/Entity/Inventory.php` — add non-persisted `isUpgrade` property with `myDonatableInventory` group
- `PoppySeedPetsAPI/src/Controller/Museum/GetDonatableItemsController.php` — replace NOT IN subquery with LEFT JOIN + upgrade-eligible WHERE clause; set `isUpgrade` flag on results
- `PoppySeedPetsAPI/src/Controller/Museum/DonateController.php` — handle upgrade path in validation and processing loops
- `PoppySeedPetsApp/src/app/model/my-inventory/my-inventory.serialization-group.ts` — add `isUpgrade` field
- `PoppySeedPetsApp/src/app/module/shared/component/inventory-item/inventory-item.component.ts` — rename `makerName` input to `subtitle`
- `PoppySeedPetsApp/src/app/module/shared/component/inventory-item/inventory-item.component.html` — display subtitle text
- `PoppySeedPetsApp/src/app/module/shared/component/inventory-item/inventory-item.component.scss` — rename `.maker` to `.subtitle`
- `PoppySeedPetsApp/src/app/module/museum/page/museum/museum-donate/museum-donate.component.ts` — add `hasUpgradeItems` flag
- `PoppySeedPetsApp/src/app/module/museum/page/museum/museum-donate/museum-donate.component.html` — pass subtitle for upgrades; add explanatory note

## Test Plan

- [ ] Items not in museum appear in donatable list (existing behavior preserved)
- [ ] Items already in museum (made by you) do NOT appear in donatable list
- [ ] Items already in museum (NOT made by you) appear in donatable list IF you own a self-made copy
- [ ] Items already in museum (NOT made by you) do NOT appear if you only own non-self-made copies
- [ ] Donating a new item creates a MuseumItem and awards Favor (existing behavior preserved)
- [ ] Donating an upgrade item updates the existing MuseumItem's createdBy and comments
- [ ] Donating an upgrade item does NOT award Favor
- [ ] Donating an upgrade item does NOT increment the ItemsDonatedToMuseum stat
- [ ] Donating a mix of new and upgrade items awards Favor only for new items
- [ ] The donated inventory item is removed from inventory in both new and upgrade cases
- [ ] "Replaces donated copy" subtitle appears on upgrade-eligible items only
- [ ] Non-upgrade items do not show a subtitle
- [ ] Explanatory note about upgrades appears at the bottom when upgrade items are present
- [ ] Explanatory note does not appear when there are no upgrade items
- [ ] Clicking the subtitle text selects the item (subtitle is inside `<app-inventory-item>`)
- [ ] Pagination still works correctly with the updated query

## Learnings

### Architectural decisions
- Used `rgba(var(--color-text-on-content-background), 0.5)` for the muted subtitle text color, following the project's existing pattern of storing RGB triplets in CSS variables and using `rgba()` with reduced opacity for muted elements (e.g. `controls.scss` uses `0.2` for borders).
- Initially showed "Made by X" on all items, but this was confusing — non-upgrade items don't need a maker label, and the label sat outside `<app-inventory-item>` so clicks didn't select the item. Refactored to: (1) a backend `isUpgrade` flag set via a lightweight query on paginated results, (2) a generic `subtitle` input on `InventoryItemComponent` (renamed from `makerName`), and (3) "Replaces donated copy" shown only on upgrades.
- The `isUpgrade` property on `Inventory` is non-persisted (no `#[ORM\Column]`) and only serialized under the `myDonatableInventory` group, so it doesn't affect other inventory responses.

### Problems encountered
- None — the ticket was very well-specified with exact code snippets, making implementation straightforward.

### Interesting tidbits
- The `MuseumItem` entity's `createdBy` is nullable (`?User`), which is why the upgrade check uses nullsafe operator (`?->getId()`) and the DQL query checks `mi.createdBy IS NULL` alongside `mi.createdBy != :user`. Museum items donated before `createdBy` tracking was added will have null values.
- The `createdBy` data was already being serialized in the API response via the `myInventory` serialization group — the frontend just wasn't displaying it.
- Doctrine's `Paginator` works correctly with the LEFT JOIN approach since the GROUP BY clauses remained unchanged.

### Rejected alternatives
- Could have used a dedicated `--muted-text-color` CSS variable, but the project doesn't define one. Using `rgba()` with reduced opacity on the existing `--color-text-on-content-background` variable is simpler and already an established pattern in the codebase.
- Could have kept the "Made by X" label on all items and just moved it inside the component — but showing the maker on non-upgrade items was noisy and didn't help the user understand which items were upgrades vs new donations.
