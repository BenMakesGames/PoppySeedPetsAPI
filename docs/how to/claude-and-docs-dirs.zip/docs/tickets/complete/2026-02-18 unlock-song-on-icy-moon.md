# Unlock Song on Icy Moon

## Summary

Add a new song ("The Dreaming Nebula") that pets unlock when they find a Fancy Teapot near an Icy Moon. The teapot hums with an unfamiliar tune, and the song is unlocked on first discovery. Subsequent teapot finds skip the unlock silently.

## Context

**Current behavior**: Pets can visit Icy Moons and encounter various events (blizzards, cryovolcanoes, crystalline entities, core exploration, etc.), with a rare 1-in-100 chance of finding a Fancy Teapot. No song unlock exists.

**New behavior**: When a pet finds a Fancy Teapot near an Icy Moon, the teapot is described as humming with an unfamiliar tune. If the pet's owner has a Jukebox installed and hasn't already unlocked this song, the song is unlocked and added to their Jukebox.

## Prerequisites

- "Unlock Songs via Pet Activities" ticket completed (`JukeboxService::unlockSongDuringPetActivity`, `SongRepository::findOneByName`, `PetActivityLogTagEnum::Jukebox`)

## Backend

### 1. Seed the New Song

Created data migration `Version20260218250003.php`:

```sql
INSERT INTO song (name, filename) VALUES ('The Dreaming Nebula', 'music/The Dreaming Nebula.ogg');
```

### 2. Inject JukeboxService into IcyMoonService

Added `JukeboxService` to the constructor and `use` statements for `JukeboxService` and `SongRepository`.

### 3. Song Unlock Tied to Fancy Teapot

Instead of unlocking on every Icy Moon encounter, the song unlock is tied to the Fancy Teapot discovery (1-in-100 chance). Both the normal and Lucky teapot branches describe the teapot as "humming with some unfamiliar tune" and call a private `maybeUnlockSong()` helper that checks Jukebox ownership and unlock status before calling `unlockSongDuringPetActivity`.

## Frontend

No frontend code changes required. The audio file `PoppySeedPetsApp/src/assets/music/The Dreaming Nebula.ogg` already exists.

## Files

### Create
- `PoppySeedPetsAPI/migrations/2026/02/Version20260218250003.php` — data migration to seed the song

### Modify
- `PoppySeedPetsAPI/src/Service/PetActivity/SpecialLocations/IcyMoonService.php` — inject `JukeboxService`, add song unlock in Fancy Teapot blocks

### Delete
- None

## Test Plan

- [x] Fancy Teapot find for a Jukebox-owning player unlocks the song and describes the teapot humming
- [x] Second Fancy Teapot find for the same player does NOT re-unlock (already unlocked)
- [x] Fancy Teapot find for a player WITHOUT a Jukebox does not attempt song unlock and produces no errors
- [x] The song appears as locked in the Jukebox dialog for players who haven't found a teapot on an Icy Moon
- [x] The song appears as unlocked (with correct comment) in the Jukebox dialog after a teapot find
- [x] The activity log entry is tagged with the Jukebox tag when the song is unlocked
- [x] Normal Icy Moon encounters (without teapot) do NOT trigger the song unlock
- [x] The data migration correctly seeds the new song into the `song` table

## Learnings

### Architectural decisions
- The prerequisite ticket's `PetActivityLogTagEnum::Music` was actually implemented as `PetActivityLogTagEnum::Jukebox`. The tagging is handled internally by `petUnlockSong`, so callers don't need to reference the tag directly.
- Song unlock was tied to the Fancy Teapot event (1-in-100) rather than every encounter, making it a rare discovery tied to a specific in-game object. Extracted a `maybeUnlockSong()` helper to avoid duplicating the guard logic across both teapot branches (normal and Lucky).

### Interesting tidbits
- The Fancy Teapot already has two branches: a base 1-in-100 roll, and a Lucky merit re-roll. The song unlock needed to be added to both. Using a private helper kept the duplication minimal.
- `SongRepository::findOneByName` is only called when a teapot is found (not every encounter), so performance is a non-issue.
