# Unlock Songs via Pet Activities

## Summary

Add the ability for pet activities to unlock new jukebox songs for the player, following the Hattier styling unlock pattern. Create a new "Music" pet activity log tag so that song-unlock activity logs are filterable. When a pet activity unlocks a song, the activity log is updated with an appropriate message and tagged with the Music tag.

## Context

**Current behavior**: Songs can only be unlocked via starter song initialization (from the "Jukebox Song Management" ticket). There is no way for players to discover new songs through gameplay.

**New behavior**: Pet activities can unlock new songs, similar to how pet activities unlock Hattier stylings. When a pet does something that would unlock a song, the pet activity log entry gets an appended message like "(A new song has been added to your Jukebox!)" and is tagged with the Music tag. The player also receives a player activity log entry: "You unlocked the song 'Song Name'!" tagged with `PlayerActivityLogTagEnum::Music`. If the player already has the song, nothing happens (idempotent). Song unlock is a "rare activity" level of interestingness.

## Prerequisites

- "Jukebox Song Management" ticket completed (Song entity, UserUnlockedSong entity, JukeboxService)

## Backend

### 1. Add Pet Activity Methods to JukeboxService

Add the following methods to `PoppySeedPetsAPI/src/Service/JukeboxService.php`, mirroring `HattierService`:

**`petUnlockSong(User $user, Song $song, string $comment, PetActivityLog $activityLog): UserUnlockedSong`**

Follows `HattierService::petUnlockAura` exactly:

- If the user already has the song unlocked, return the existing record (no-op)
- Otherwise, create and persist a new `UserUnlockedSong`
- If the user doesn't have the Jukebox feature yet — this shouldn't happen (songs require a Jukebox), so just append the normal message
- Append to the activity log: `'(A new song has been added to your Jukebox!)'`
- Set interestingness to `PetActivityLogInterestingness::RareActivity`
- Update the per-request cache
- Create a player activity log via `PlayerLogFactory::create` with message `'You unlocked the song "X"!'` and tag `PlayerActivityLogTagEnum::Music`

**`petMaybeUnlockSong(Pet $pet, Song|string $song, string $activityLogMessage, string $songUnlockComment): ?PetActivityLog`**

Follows `HattierService::petMaybeUnlockAura`:

- Accepts song by entity or by name (string lookup)
- If user already has the song, return null (no-op, no log created)
- If the pet's owner doesn't have a Jukebox installed, return null (can't unlock songs without a Jukebox)
- Create an unread pet activity log with the provided message
- Call `petUnlockSong` to handle the unlock + log tagging
- Return the activity log

**`unlockSongDuringPetActivity(Pet $pet, PetActivityLog $activityLog, Song $song, string $description, string $songUnlockComment): void`**

Follows `HattierService::unlockAuraDuringPetActivity`:

- For use when an activity log already exists and the song unlock is appended to it
- Appends the description to the existing activity log
- Sets interestingness to `PetActivityLogInterestingness::RareActivity`
- Calls `petUnlockSong` to handle the actual unlock

### 2. Add Song Lookup Helper

Create a static lookup method, either in `JukeboxService` or as a new `PoppySeedPetsAPI/src/Functions/SongRepository.php` helper (following `EnchantmentRepository` pattern):

```php
public static function findOneByName(EntityManagerInterface $em, string $name): Song
```

This is needed so that pet activity services can reference songs by name string rather than entity, matching the `EnchantmentRepository::findOneByName` pattern used by the Hattier.

### 3. Add PetActivityLogTagEnum::Music

Add `public const string Music = 'Music';` to `PoppySeedPetsAPI/src/Enum/PetActivityLogTagEnum.php`.

### 4. Add Music Tag to Activity Logs

When `petUnlockSong` or `unlockSongDuringPetActivity` is called, the activity log should be tagged with the Music tag:

```php
$activityLog->addTags(PetActivityLogTagHelpers::findByNames($this->em, [PetActivityLogTagEnum::Music]));
```

### 5. Database Migration

**Data migration** (hand-written):

Insert a new row into the `pet_activity_log_tag` table:

```sql
INSERT INTO pet_activity_log_tag (title, emoji, color) VALUES ('Music', '🎵', '...');
```

Choose a color that fits the existing tag palette (6-character hex, no `#` prefix). The emoji `🎵` (musical note) is a natural fit.

## Frontend

### 1. Auto-Add Newly Unlocked Songs to Playlist (Optional Enhancement)

When the frontend receives an activity log that mentions a song unlock, it could automatically add the new song to the `jukebox-playlist` in localStorage. This would mean newly unlocked songs start playing right away (once the playback ticket is done).

This could be implemented by:
- Checking activity log entries for a recognizable pattern (e.g. a special tag or structure from the API)
- Or by having the JukeboxSongsDialog re-sync with the API on next open (the player would need to manually enable the new song)

The simpler approach is to just let the player discover the new song in the Manage dialog and toggle it on manually. Choose based on what feels right during implementation.

## Files

### Create
- `PoppySeedPetsAPI/src/Functions/SongRepository.php` (optional — could be a method on JukeboxService instead)
- `PoppySeedPetsAPI/migrations/` (hand-written data migration for the Music tag)

### Modify
- `PoppySeedPetsAPI/src/Service/JukeboxService.php` — add `petUnlockSong`, `petMaybeUnlockSong`, `unlockSongDuringPetActivity` methods
- `PoppySeedPetsAPI/src/Enum/PetActivityLogTagEnum.php` — add `Music` constant

### Delete
- None

## Test Plan

- [x] `petMaybeUnlockSong` creates an activity log and unlocks the song when the user doesn't already have it
- [x] `petMaybeUnlockSong` returns null and does not create a log when the user already has the song
- [x] `petMaybeUnlockSong` returns null when the user's Library has no Jukebox
- [x] `petUnlockSong` is idempotent — calling it twice for the same song does not create duplicates
- [x] Unlocked-song activity logs have `RareActivity` interestingness level
- [x] Unlocked-song activity logs are tagged with the "Music" pet activity log tag
- [x] A player activity log entry is created with `PlayerActivityLogTagEnum::Music`
- [x] The Music tag appears in the pet activity log filter list with the correct emoji and color
- [x] `unlockSongDuringPetActivity` appends to an existing activity log correctly
- [x] Songs can be looked up by name string (via `SongRepository::findOneByName` or equivalent)

## Learnings

### Architectural decisions
- Created `SongRepository` as a separate static helper class (matching `EnchantmentRepository` pattern) rather than adding `findOneByName` as a method on `JukeboxService`. This keeps the service focused on business logic and the repository helper focused on data access with caching.
- Simplified `petUnlockSong` compared to HattierService's `petUnlockAura` — no need for a "first unlock" feature-unlock flow (Hattier auto-unlocks itself on first aura discovery), since songs require the Jukebox to already be installed. This eliminated the `UnlockableFeatureEnum` / `UserUnlockedFeatureHelpers` dependency.
- Chose to add the Music tag in `petUnlockSong` (the central unlock method) rather than in each caller, so all song unlocks automatically get tagged.

### Problems encountered
- PHPStan level 10 flags `getOneOrNullResult()` as returning `mixed`. The existing `EnchantmentRepository` has this same issue but it's baselined. Fixed with a `/** @var Song|null */` annotation instead of adding to the baseline.

### Interesting tidbits
- Pet activity log tags use Font Awesome icon classes (e.g., `fa-solid fa-music`) for their "emoji" field, not Unicode emojis. The `user_activity_log_tag` table uses actual Unicode emojis (`🎵`). The field is `varchar(100)` to accommodate FA class names.
- Pet activity log tag IDs are explicitly set in migrations (latest was 100 for Hedge Maze Light Puzzle). Used 101 for Music.
- The `petMaybeUnlockSong` signature is simpler than `petMaybeUnlockAura` because there's no hat/enchantment interaction — songs don't have the "apply to hat" mechanic, so only one activity log message is needed instead of two.

### Frontend decision
- Chose the simpler approach for the optional frontend enhancement: players discover new songs in the Manage dialog and toggle them on manually. No frontend changes were needed for this ticket.
