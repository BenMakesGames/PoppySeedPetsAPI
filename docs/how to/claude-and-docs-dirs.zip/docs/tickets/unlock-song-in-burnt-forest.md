# Unlock Song in The Burnt Forest

## Summary

Add a new song that pets unlock during any encounter in The Burnt Forest. The song unlocks on the pet's first visit (appended to the encounter's activity log) and is silently skipped on subsequent visits.

## Context

**Current behavior**: Pets can visit The Burnt Forest and encounter various events (fairies, fire spirits, tentacles, etc.), but no song unlock exists. The Jukebox infrastructure and pet-activity song unlock methods exist but no location-specific song has been wired up yet.

**New behavior**: On any Burnt Forest encounter, if the pet's owner has a Jukebox installed and hasn't already unlocked this song, the activity log gets an appended message about hearing a melody, and the song is unlocked. This follows the same pattern as the "of Living Flame" aura unlock in `findBurningTree()`, but applies to all encounters rather than a single one.

## Prerequisites

- "Unlock Songs via Pet Activities" ticket completed (`JukeboxService::unlockSongDuringPetActivity`, `SongRepository::findOneByName`, `PetActivityLogTagEnum::Music`)

## Backend

### 1. Seed the New Song

Create a hand-written data migration to insert the new song into the `song` table:

```sql
INSERT INTO song (name, filename) VALUES ('<song_name>', 'music/<song_filename>');
```

The song name and filename will be provided at implementation time along with the audio file. Follow the existing naming convention (e.g. `frogs_life` / `music/frogs_life.ogg`).

### 2. Add the Audio File

Place the provided audio file at `PoppySeedPetsApp/src/assets/music/<song_filename>`. The file will be provided at implementation time.

### 3. Inject JukeboxService into BurntForestService

Add `JukeboxService` to the constructor of `PoppySeedPetsAPI/src/Service/PetActivity/SpecialLocations/BurntForestService.php`:

```php
public function __construct(
    private readonly PetExperienceService $petExperienceService,
    private readonly InventoryService $inventoryService,
    private readonly IRandom $rng,
    private readonly HattierService $hattierService,
    private readonly EntityManagerInterface $em,
    private readonly FieldGuideService $fieldGuideService,
    private readonly JukeboxService $jukeboxService       // ← new
)
```

Add the corresponding `use` statement for `App\Service\JukeboxService`.

### 4. Add Song Unlock Check in `run()`

In the `run()` method, after the encounter match expression produces `$activityLog` and before the location tag / field guide / badge logic, add a song unlock check. Follow the same guard pattern used for the "of Living Flame" aura in `findBurningTree()`:

```php
$activityLog = match ($roll) { ... };

// Song unlock — check Jukebox ownership and song unlock status
$song = SongRepository::findOneByName($this->em, '<song_name>');
if ($pet->getOwner()->getLibrary()?->getHasJukebox()
    && !$this->jukeboxService->userHasUnlockedSong($pet->getOwner(), $song))
{
    $this->jukeboxService->unlockSongDuringPetActivity(
        $pet,
        $activityLog,
        $song,
        ' As they left, they heard a haunting melody drifting through the ashes...',
        ActivityHelpers::PetName($pet) . ' heard a haunting melody in the Burnt Forest...'
    );
}

$activityLog
    ->addTags(...)
    ->setChanges(...)
;
```

Add the `use` statement for `App\Functions\SongRepository`.

**Note**: The description text (first string) is appended to the existing activity log entry. The comment text (second string) becomes the `UserUnlockedSong.comment` visible in the Jukebox dialog. Adjust the flavor text as desired during implementation — the above is a suggestion.

## Frontend

No frontend code changes required. The new song will automatically appear in the Jukebox management dialog (locked until unlocked, then playable) via the existing `GET /library/jukebox/songs` endpoint.

### 1. Add Audio Asset

Place the provided audio file at `PoppySeedPetsApp/src/assets/music/<song_filename>`. This is the only frontend-side change.

## Files

### Create
- `PoppySeedPetsAPI/migrations/` — hand-written data migration to seed the new song
- `PoppySeedPetsApp/src/assets/music/<song_filename>` — the audio file (provided at implementation time)

### Modify
- `PoppySeedPetsAPI/src/Service/PetActivity/SpecialLocations/BurntForestService.php` — inject `JukeboxService`, add song unlock check in `run()`

### Delete
- None

## Test Plan

- [ ] First Burnt Forest encounter for a Jukebox-owning player unlocks the song and appends the melody message to the activity log
- [ ] Second Burnt Forest encounter for the same player does NOT append the melody message (already unlocked)
- [ ] Burnt Forest encounter for a player WITHOUT a Jukebox does not attempt song unlock and produces no errors
- [ ] The song appears as locked in the Jukebox dialog for players who haven't visited the Burnt Forest
- [ ] The song appears as unlocked (with correct comment) in the Jukebox dialog after a Burnt Forest encounter
- [ ] The activity log entry is tagged with the Music tag when the song is unlocked
- [ ] The unlock works regardless of which specific encounter roll occurs (rolls 1–15 all trigger the check)
- [ ] The data migration correctly seeds the new song into the `song` table
