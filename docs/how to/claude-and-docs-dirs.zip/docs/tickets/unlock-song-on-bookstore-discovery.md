# Unlock Song on Bookstore Discovery

## Summary

Add a song unlock ("Downtown on a Tuesday") that triggers when a pet discovers the Bookstore. Include a retroactive migration to grant the song to players who have already discovered the Bookstore.

## Context

**Current behavior**: Pets can discover the Bookstore through the feature discovery system in `PetActivityService::discoverNewFeature()`, but no song unlock is associated with this event.

**New behavior**: When a pet discovers the Bookstore, if the pet's owner has a Jukebox installed and hasn't already unlocked this song, the discovery activity log gets an appended message about hearing music, and the song "Downtown on a Tuesday" is unlocked. A retroactive data migration grants the song to all existing players who have already discovered the Bookstore and own a Jukebox.

## Prerequisites

- "Unlock Songs via Pet Activities" ticket completed (`JukeboxService::unlockSongDuringPetActivity`, `SongRepository::findOneByName`, `PetActivityLogTagEnum::Music`)

## Backend

### 1. Seed the New Song

Create a hand-written data migration to insert the new song into the `song` table:

```sql
INSERT INTO song (name, filename) VALUES ('downtown_on_a_tuesday', 'music/Downtown on a Tuesday.ogg');
```

Follow the existing migration pattern in `PoppySeedPetsAPI/migrations/2026/02/Version20260218250001.php`.

### 2. Retroactive Backfill for Existing Players

In the same migration, backfill the song for all users who have already discovered the Bookstore AND have a Jukebox installed. This follows the same backfill pattern used in `Version20260218250001.php` for starter songs:

```sql
INSERT INTO user_unlocked_song (user_id, song_id, unlocked_on, comment)
SELECT uuf.user_id, s.id, NOW(), 'Your pet discovered this song when they found the Bookstore.'
FROM user_unlocked_feature uuf
JOIN library l ON l.owner_id = uuf.user_id
CROSS JOIN song s
WHERE uuf.feature = 'Bookstore'
AND l.has_jukebox = 1
AND s.name = 'downtown_on_a_tuesday'
```

This ensures the `user_unlocked_song` unique constraint on `(user_id, song_id)` is respected — each user gets the song at most once.

### 3. Inject JukeboxService into PetActivityService

Add `JukeboxService` to the constructor of `PoppySeedPetsAPI/src/Service/PetActivityService.php`:

```php
public function __construct(
    private readonly Clock $clock,
    private readonly EntityManagerInterface $em,
    private readonly ResponseService $responseService,
    private readonly GenericAdventureService $genericAdventureService,
    // ... existing parameters ...
    private readonly JukeboxService $jukeboxService       // ← new
)
```

Add the corresponding `use` statements for `App\Service\JukeboxService` and `App\Functions\SongRepository`.

### 4. Add Song Unlock to Bookstore Discovery

In the `discoverNewFeature()` method (around line 477), modify the Bookstore discovery branch. Currently it reads:

```php
if(!$pet->getOwner()->hasUnlockedFeature(UnlockableFeatureEnum::Bookstore))
    return $this->genericAdventureService->discoverFeature($pet, UnlockableFeatureEnum::Bookstore, 'Bookstore');
```

Change it to capture the activity log, add the song unlock check, then return:

```php
if(!$pet->getOwner()->hasUnlockedFeature(UnlockableFeatureEnum::Bookstore))
{
    $activityLog = $this->genericAdventureService->discoverFeature($pet, UnlockableFeatureEnum::Bookstore, 'Bookstore');

    $song = SongRepository::findOneByName($this->em, 'downtown_on_a_tuesday');
    if ($pet->getOwner()->getLibrary()?->getHasJukebox()
        && !$this->jukeboxService->userHasUnlockedSong($pet->getOwner(), $song))
    {
        $this->jukeboxService->unlockSongDuringPetActivity(
            $pet,
            $activityLog,
            $song,
            ' Inside, a melody was playing softly from the café speakers...',
            ActivityHelpers::PetName($pet) . ' heard a song playing inside the Bookstore...'
        );
    }

    return $activityLog;
}
```

**Note**: The description text (first string) is appended to the existing discovery activity log entry. The comment text (second string) becomes the `UserUnlockedSong.comment` visible in the Jukebox dialog. Adjust the flavor text as desired during implementation — the above is a suggestion.

## Frontend

No frontend code changes required. The audio file `PoppySeedPetsApp/src/assets/music/Downtown on a Tuesday.ogg` already exists. The new song will automatically appear in the Jukebox management dialog (locked until unlocked, then playable) via the existing `GET /library/jukebox/songs` endpoint.

## Files

### Create
- `PoppySeedPetsAPI/migrations/` — hand-written data migration to seed the song and backfill existing Bookstore-discovering, Jukebox-owning players

### Modify
- `PoppySeedPetsAPI/src/Service/PetActivityService.php` — inject `JukeboxService`, add song unlock to Bookstore discovery branch in `discoverNewFeature()`

### Delete
- None

## Test Plan

- [ ] Discovering the Bookstore for a Jukebox-owning player unlocks the song and appends the café melody message to the discovery activity log
- [ ] Discovering the Bookstore for a player WITHOUT a Jukebox does not attempt song unlock and produces no errors
- [ ] The song appears as locked in the Jukebox dialog for players who haven't discovered the Bookstore
- [ ] The song appears as unlocked (with correct comment) in the Jukebox dialog after Bookstore discovery
- [ ] The activity log entry is tagged with the Music tag when the song is unlocked
- [ ] The data migration correctly seeds "downtown_on_a_tuesday" into the `song` table
- [ ] The retroactive backfill grants the song to users who have both the Bookstore feature unlocked and a Jukebox installed
- [ ] The retroactive backfill does NOT grant the song to users who have the Bookstore but no Jukebox
- [ ] The retroactive backfill does NOT grant the song to users who have a Jukebox but haven't discovered the Bookstore
- [ ] Running the migration a second time does not cause duplicate key errors (idempotent via unique constraint)
